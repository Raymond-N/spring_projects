package com.codingdojo.coreassignment;

public class BatTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Bat bat = new Bat();
		
		bat.attackTown();
		bat.attackTown();
		bat.attackTown();
		
		bat.eatHumans();
		bat.eatHumans();
		
		bat.fly();
		bat.fly();

	}

}
