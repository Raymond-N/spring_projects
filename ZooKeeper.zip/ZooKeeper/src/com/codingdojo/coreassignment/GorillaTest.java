package com.codingdojo.coreassignment;

public class GorillaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Gorilla gorilla = new Gorilla(100);
		
		gorilla.throwSomething();
		gorilla.throwSomething();
		gorilla.throwSomething();
		
		gorilla.eatBananas();
		gorilla.eatBananas();
		
		gorilla.climb();
		
	}

}
